﻿namespace Motorcenter.Data.Entities;

public class VehicleTypeVehicle
{
    public int VehicleId { get; set; }
    public int VehicleTypeId { get; set; }

}
