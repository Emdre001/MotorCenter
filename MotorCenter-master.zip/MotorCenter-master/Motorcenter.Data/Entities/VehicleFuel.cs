﻿namespace Motorcenter.Data.Entities;

public class VehicleFuel
{
    public int VehicleId { get; set; }
    public int FuelId { get; set; }

}
