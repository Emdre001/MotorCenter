﻿namespace Motorcenter.Data.Entities;

public class VehicleColor
{
    public int VehicleId { get; set; }
    public int ColorId { get; set; }
}
