﻿namespace Motorcenter.Data.Entities;

public class VehicleTypeFilter
{
    public int FilterId { get; set; }
    public int VehicleTypeId { get; set; }
}
