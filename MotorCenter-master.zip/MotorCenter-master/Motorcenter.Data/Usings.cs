﻿global using Motorcenter.Data.Shared.Interfaces;
global using Motorcenter.Data.Shared.Enums;