﻿namespace Motorcenter.Data.Shared.Enums;
public enum OptionType
{
    CheckBox, RadioButton, Slider
}
