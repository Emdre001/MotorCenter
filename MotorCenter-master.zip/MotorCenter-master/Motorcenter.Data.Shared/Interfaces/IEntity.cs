﻿namespace Motorcenter.Data.Shared.Interfaces;

public interface IEntity
{
    public int Id { get; set; }
}