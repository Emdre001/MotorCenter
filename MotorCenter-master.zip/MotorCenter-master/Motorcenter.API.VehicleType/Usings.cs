﻿global using Motorcenter.Data.Contexts;
global using Microsoft.EntityFrameworkCore;